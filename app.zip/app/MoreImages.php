<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MoreImages extends Model
{
    //
}
